# Aula_FI
Aulas de fundamentos da Informatica
